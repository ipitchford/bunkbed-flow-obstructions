"""Reviewer checks, independent subset enumerator and added exact test cases."""
from pathlib import Path
from fractions import Fraction as F
import sys,subprocess,json,time,shutil
ROOT=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path('/mnt/data/bunkbed_review/source/evidence_press_bunkbed_v0_1')
OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'code'))
import verify_core as vc

def require(ok,message):
    if not ok: raise RuntimeError(message)

def base(word,L):
    t=max(word)+1;n=t+len(word)*L+1;E=set()
    for j,c in enumerate(word):
        for r in range(L):E.add((t+j*L+r,t+j*L+r+1))
        for r in range(L+1):E.add(tuple(sorted((c,t+j*L+r))))
    return n,sorted(E),t,t,n-1

def histogram(word,L,wired):
    n,E,t,u,v=base(word,L)
    f=(lambda a,l:a if a<t else t+2*(a-t)+l) if wired else (lambda a,l:2*a+l)
    edges=[(f(a,l),f(b,l),0) for a,b in E for l in (0,1)]
    if wired:edges += [(f(a,0),f(a,1),1) for a in range(t,n)]
    else: edges += [(f(a,0),f(a,1),int(a<t)) for a in range(n)]
    nv=2*n-t if wired else 2*n
    text=f'{nv} {len(edges)} {f(u,0)} {f(v,0)} {f(v,1)}\n'+''.join(f'{a} {b} {k}\n' for a,b,k in edges)
    run=subprocess.run([str(OUT/'independent_histogram')],input=text,text=True,capture_output=True,check=True)
    return [tuple(map(int,line.split())) for line in run.stdout.splitlines()],len(edges),t

def val(hist,q,x,b):return sum(F(c)*q**k*x**a for k,a,bb,c in hist if b==bb)

def main():
    start=time.time();rows=[]
    subprocess.run(['g++','-std=c++17','-O2',str(OUT/'independent_histogram.cpp'),'-o',str(OUT/'independent_histogram')],check=True)
    for word in ([0,1],[0,1,2]):
        hist,m,t=histogram(word,1,True)
        require(all(b==0 for k,a,b,c in hist),'Non-post vertical cancellation failed')
        for q,x in ((F(1,2),F(2,3)),(F(11,10),F(1)),(F(3,2),F(1,3)),(F(2),F(1)),(F(21,10),F(2,3)),(F(5,2),F(3)),(F(3),F(1))):
            num=val(hist,q,x,0)
            aa,_=vc.core_dp(q,x,1,word);bb=vc.core_potts(q,x,1,word)
            require(num==aa==bb,'Three-way exact core check failed')
            rows.append({'word':word,'q':str(q),'x':str(x),'numerator':str(num)})
        rows.append({'post_cancellation_word':word,'configurations':2**m,'all_positive_extra_vertical_coefficients_zero':True})
    hist,m,t=histogram([0,1],1,False)
    ch,_,_=histogram([0,1],1,True)
    require({(k,a):c for k,a,b,c in hist if b==t}=={(k,a):c for k,a,b,c in ch if b==0},'Leading post coefficient identity failed')
    rows.append({'full_bunkbed_leading_post_coefficient':'matches contracted core polynomial coefficientwise','configurations':2**m})
    # Extra matrix/DP cases with q-r negative, zero, and positive.
    extra=0
    for word in ([0,1,2],[0,1,0,2],[0,1,2,0,2,1],[0,1,2]*2):
        for q,x in ((F(11,10),F(1,3)),(F(3,2),F(2)),(F(21,10),F(2,3)),(F(5,2),F(3)),(F(2),F(1)),(F(3),F(1))):
            a,_=vc.core_dp(q,x,2,word);b=vc.core_potts(q,x,2,word)
            require(a==b,'Added finite real-q transfer case mismatch');extra+=1
    rows.append({'additional_DP_Potts_cases':extra,'status':'PASS'})
    # Independent polynomial signature enumeration of a three-edge path.
    from collections import Counter
    separate=Counter();together=Counter()
    for mask in range(8):
        p=list(range(4))
        def find(a):
            while p[a]!=a:a=p[a]
            return a
        for i in range(3):
            if mask>>i&1:p[find(i)]=find(i+1)
        internal=len({find(a) for a in range(4)}-{find(0),find(3)})
        target=together if find(0)==find(3) else separate
        target[internal,mask.bit_count()]+=1
    require(separate=={(2,0):1,(1,1):3,(0,2):3} and together=={(0,3):1},'Pendant signature mismatch')
    rows.append({'pendant_separate':'q**2 + 3*q*x + 3*x**2','pendant_together':'x**3','status':'PASS'})
    witness=json.load(open(ROOT/'certificates/flow_witness.json'))
    adj={i:set() for i in range(witness['n'])}
    for a,b in witness['edges']:adj[a].add(b);adj[b].add(a)
    seen={0};todo=[0]
    while todo:
        for a in adj[todo.pop()]:
            if a not in seen:seen.add(a);todo.append(a)
    require(len(seen)==12 and all(len(v)==4 for v in adj.values()),'Witness properties failed')
    rows.append({'witness_connected':True,'degree_sequence':sorted(map(len,adj.values()))})
    out={'status':'PASS','checks':rows,'elapsed_seconds':time.time()-start}
    (OUT/'additional_checks.json').write_text(json.dumps(out,indent=2))
    print(json.dumps(out,indent=2))
if __name__=='__main__':main()
