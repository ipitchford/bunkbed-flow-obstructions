"""Reviewer negative controls. All modifications are to a temporary copy."""
import shutil,json,subprocess,sys,tempfile
from pathlib import Path
root=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path('/mnt/data/bunkbed_review/source/evidence_press_bunkbed_v0_1')
out=Path(__file__).resolve().parent
with tempfile.TemporaryDirectory(prefix='bunkbed_mutation_') as tmp:
    p=Path(tmp)/'copy';shutil.copytree(root,p)
    cert=p/'certificates/flow_witness.json';j=json.loads(cert.read_text())
    j['flow_coefficients'][0]+=1;cert.write_text(json.dumps(j))
    normal=subprocess.run([sys.executable,str(p/'code/verify_flow.py')],text=True,capture_output=True)
    optimized=subprocess.run([sys.executable,'-O',str(p/'code/verify_flow.py')],text=True,capture_output=True)
    hash_result=subprocess.run(['sha256sum','-c','SHA256SUMS'],cwd=p,text=True,capture_output=True)
    # Restore original, then test the complete unmodified runner under -O.
    shutil.copyfile(root/'certificates/flow_witness.json',cert)
    fullopt=subprocess.run([sys.executable,'-O',str(p/'code/run_all.py')],text=True,capture_output=True)
    receipt={'mutation':'Increment expected flow polynomial constant coefficient by 1 in temporary copy only',
        'normal_verify_flow_exit_code':normal.returncode,
        'normal_detected_mismatch':'assert co==expected' in normal.stderr,
        'optimized_verify_flow_exit_code':optimized.returncode,
        'optimized_reported_status':json.loads(optimized.stdout).get('status') if optimized.returncode==0 else None,
        'separate_hash_check_detected_mutation':hash_result.returncode!=0,
        'unmodified_full_runner_optimized_exit_code':fullopt.returncode,
        'unmodified_full_runner_optimized_error':fullopt.stderr.splitlines()[-1] if fullopt.stderr else None,
        'interpretation':'Standalone verify_flow accepts a wrong expected coefficient under -O because equality assertions are removed. The full runner under -O instead crashes because its header read is inside an assert. Default verification correctly rejects corruption and original certificates pass. The separate hash check also rejects the mutation. No mathematical counterexample is implied.'}
    (out/'mutation_check.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt,indent=2))
