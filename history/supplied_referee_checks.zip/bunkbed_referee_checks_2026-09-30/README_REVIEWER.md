# Bunkbed candidate: referee checks, 30 September 2026

These files document tests carried out during review of Evidence Press bunkbed v0.1.0.
The original bundle has not been modified. This is not a proof-assistant certificate,
a complete independent reimplementation, or an external human review.

## Results

* All 23 manifest-covered files matched their supplied SHA-256 digests.
* The original default verification suite passed (see replay.json).
* Reviewer-written exhaustive signed-count enumeration confirmed post cancellation
  coefficientwise over 32,768 and 4,194,304 contracted-graph configurations.
* The full 5-vertex base bunkbed test enumerated 131,072 configurations and verified
  the leading post-activity coefficient equals the omitted-vertical core polynomial.
* Independent enumerator results agreed with the supplied frontier and Potts
  algorithms on 14 rational-parameter cases. Another 24 new cases compared the
  two supplied algorithms. These extra tests supplement, not replace, the proof.
* Independent three-edge-path enumeration recovered q^2+3qx+3x^2 and x^3.
* Negative-control test: changing an expected flow coefficient makes normal
  verify_flow.py fail, but python -O verify_flow.py reports PASS. The separate
  manifest check detects the mutation. The full runner under -O instead crashes
  because reading its edge-list header is inside an assert. Default verification
  of the unmodified candidate passes. See mutation_check.json.

## Reproduction

Requires Python 3.11+ and g++ supporting C++17. No third-party Python modules.
With the original candidate extracted separately, run:

    python additional_checks.py /path/to/evidence_press_bunkbed_v0_1
    python mutation_check.py /path/to/evidence_press_bunkbed_v0_1

The first command compiles the independent C++ enumerator locally and writes
additional_checks.json. The second uses only a temporary copy for mutations and
writes mutation_check.json. Timings are environment-dependent.

The original replay can be repeated in the original candidate root with:

    python code/run_all.py
    sha256sum -c SHA256SUMS

## Interpretation

The mathematical proof and all original default checks survived this review.
The optimisation-mode defect affects validation robustness, not the truth of
the reported polynomial or the general transfer theorem. Replace security-
critical/proof-critical asserts with explicit checks or reject optimised mode,
move side-effecting file reads outside assertions, and retain mutation tests.
