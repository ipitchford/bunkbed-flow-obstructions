// Reviewer-written exhaustive random-cluster signed-count enumerator.
// Third edge field is the category whose open edges are counted separately.
#include <iostream>
#include <vector>
#include <cstdint>
#include <stdexcept>
using namespace std;
int main(){
 int n,m,s,u,v; if(!(cin>>n>>m>>s>>u>>v)||n<1||n>60||m<0||m>28)return 2;
 struct Edge{int a,b,kind;};vector<Edge> e(m);int special=0;
 for(auto &z:e){if(!(cin>>z.a>>z.b>>z.kind)||z.a<0||z.b<0||z.a>=n||z.b>=n)return 3; special+=z.kind;}
 vector<int64_t> hist((n+1)*(m+1)*(special+1));
 for(uint64_t mask=0;mask<(1ULL<<m);++mask){
   int p[60],sz[60];for(int i=0;i<n;++i){p[i]=i;sz[i]=1;}int k=n,a=0,b=0;
   auto root=[&](int z){while(p[z]!=z)z=p[z];return z;};
   for(int j=0;j<m;++j)if((mask>>j)&1){auto z=e[j];if(z.kind)++b;else ++a;int r=root(z.a),t=root(z.b);if(r!=t){if(sz[r]<sz[t])swap(r,t);p[t]=r;sz[r]+=sz[t];--k;}}
   int sign=int(root(s)==root(u))-int(root(s)==root(v));
   hist[(k*(m+1)+a)*(special+1)+b]+=sign;
 }
 for(int k=0;k<=n;++k)for(int a=0;a<=m;++a)for(int b=0;b<=special;++b){auto z=hist[(k*(m+1)+a)*(special+1)+b];if(z)cout<<k<<' '<<a<<' '<<b<<' '<<z<<'\n';}
}
